Description of Files:
Yahtzee.ipynb - The Python program written to simulate the game of Yahtzee. 